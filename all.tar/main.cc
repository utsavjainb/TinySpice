#include <iostream>
using namespace std;
int yyparse();


int main()
{
    yyparse();
    return 0;
}
