#include "symtab.h"

void table :: enter_symbol (const char *name, type_kind type)
{
}

type_kind table :: find_symbol (char * name)
{
}

void table :: enter_scope()
{
}

void table :: exit_scope()
{
}


type_kind type_check(int op, type_kind left, type_kind right)
{
}

